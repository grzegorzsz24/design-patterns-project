insert into
    forum (comments_number, title, content, created_at, user_id, car_id)
values
    (0, 'Luksus i Elegancja: Dyskusja o Ferrari Roma', '', '2023-11-06 12:00:12', 1, 2),
    (0, 'Ferrari Monza SP2: Dzielenie się Pasją do Klasycznych Sportowych Samochodów', '', '2023-11-06 12:00:12', 2, 3),
    (0, 'Lamborghini Huracan: Siła i Szybkość na Forum', '', '2023-11-06 12:00:12', 3, 4);