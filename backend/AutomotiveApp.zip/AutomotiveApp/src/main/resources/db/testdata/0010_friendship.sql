insert into
    friendship (id, first_user_id, second_user_id)
values
    (1, 3, 4);