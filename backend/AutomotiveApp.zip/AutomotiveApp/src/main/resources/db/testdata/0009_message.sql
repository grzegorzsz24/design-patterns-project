insert into
    message (id, sender_id, receiver_id, channel_id, message, created_at)
values
    (1, 3, 4, 1, 'Siema', '2023-11-16T16:00:00'),
    (2, 4, 3, 1, 'Siema', '2023-11-16T16:01:00');