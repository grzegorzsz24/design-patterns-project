insert into
    channel (id, sender_id, receiver_id)
values
    (1, 3, 4);