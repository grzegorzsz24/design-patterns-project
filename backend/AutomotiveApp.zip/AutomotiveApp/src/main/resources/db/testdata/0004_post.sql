insert into
    post (content, user_id, posted_at, is_liked, likes_number, comments_number)
values
    ('Cześć, zobaczcie moją nową furę', 1, '2023-11-06 12:00:12', false, 0, 0),
    ('Dzisiaj stałem się szczęśliwym właścicielem mojego ulubionego auta - nowego Ferrai! Nie mogę doczekać się jazdy. Jaki jest Wasz ulubiony model?', 2, '2023-11-05 11:25:12', false, 0, 0),
    ('Mam do sprzedania mojego ukochanego SUV-a w niesamowitym stanie. To prawdziwa okazja dla miłośników SUV-ów. Zapraszam do kontaktu.', 4, '2023-11-04 09:25:11', false, 0, 0);