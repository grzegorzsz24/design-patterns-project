insert into
    file (file_url, post_id, user_id, event_id)
values
    ('default_profile_picture.jpg', null, 1, null),
    ('default_profile_picture.jpg', null, 2, null),
    ('default_profile_picture.jpg', null, 3, null),
    ('default_profile_picture.jpg', null, 4, null),
    ('audi.jpg', 1, null, null),
    ('ferrari.jpg', 2, null, null),
    ('suv.jpg', 3, null, null),
    ('targi_motoryzacyjne.jpg', null, null, 1),
    ('classic.jpg', null, null, 2),
    ('rally.jpg', null, null, 3);