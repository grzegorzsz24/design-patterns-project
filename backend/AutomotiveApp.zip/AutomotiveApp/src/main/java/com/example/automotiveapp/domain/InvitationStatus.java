package com.example.automotiveapp.domain;

public enum InvitationStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
