package com.example.automotiveapp.domain;

public enum UserFriendshipStatus {
    FRIENDS,
    INVITATION_SENT,
    INVITATION_RECEIVED,
    NOT_FRIENDS
}
