package com.example.automotiveapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FriendshipDto {
    private Long id;
    private Long user1;
    private Long user2;
}
