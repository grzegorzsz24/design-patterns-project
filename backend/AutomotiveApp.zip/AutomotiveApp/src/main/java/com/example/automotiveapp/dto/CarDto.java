package com.example.automotiveapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarDto {
    private String brand;
    private String model;
}
