package com.example.automotiveapp.domain;

public enum ReportType {
    POST_REPORT,
    FORUM_REPORT,
    EVENT_REPORT
}
